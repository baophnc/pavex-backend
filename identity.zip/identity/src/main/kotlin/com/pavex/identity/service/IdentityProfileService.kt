package com.pavex.identity.service

import com.pavex.contracts.identity.IdentityAuthContext
import com.pavex.contracts.identity.MerchantEligibilityResponse
import com.pavex.identity.dto.IdentityProfileResponse
import com.pavex.contracts.identity.ProvisionIdentityRequest
import com.pavex.identity.dto.UpdateIdentityProfileRequest
import com.pavex.identity.entity.AccountStatus
import com.pavex.identity.entity.ProfileStatus
import com.pavex.identity.entity.UserAccount
import com.pavex.identity.entity.UserProfile
import com.pavex.identity.exception.UserNotFoundException
import com.pavex.identity.repository.UserAccountRepository
import com.pavex.identity.repository.UserProfileRepository
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.Instant
import java.util.UUID

@Service
class IdentityProfileService(
    private val accounts: UserAccountRepository,
    private val profiles: UserProfileRepository,
    private val roleService: RoleService,
) {

    @Transactional
    fun provision(request: ProvisionIdentityRequest): IdentityProfileResponse {
        val normalizedEmail = request.email.trim().lowercase()
        val requestedStatus = AccountStatus.valueOf(request.status.trim().uppercase())
        val now = Instant.now()
        val existing = accounts.findById(request.userId).orElse(null)

        val account = if (existing == null) {
            accounts.save(
                UserAccount(
                    id = request.userId,
                    email = normalizedEmail,
                    status = requestedStatus,
                    emailVerified = request.emailVerified,
                    createdAt = now,
                    updatedAt = now,
                )
            )
        } else {
            val authorizationChanged = existing.status != requestedStatus
            existing.email = normalizedEmail
            existing.status = requestedStatus
            existing.emailVerified = request.emailVerified
            if (authorizationChanged) {
                existing.authorizationVersion += 1
            }
            existing.updatedAt = now
            accounts.save(existing)
        }

        if (request.roles.isEmpty()) {
            if (existing == null) {
                roleService.assignDefaultCustomerRole(account.id, now)
            }
        } else {
            roleService.bootstrapRoles(
                userId = account.id,
                rawRoleCodes = request.roles,
                now = now,
            )
        }

        val existingProfile = profiles.findById(account.id).orElse(null)
        val displayName = normalize(request.displayName)
        val avatarUrl = normalize(request.avatarUrl)
        val profile = if (displayName != null || avatarUrl != null) {
            val target = existingProfile ?: UserProfile(
                userId = account.id,
                createdAt = now,
                updatedAt = now,
            )
            if (displayName != null) target.displayName = displayName
            if (avatarUrl != null) target.avatarUrl = avatarUrl
            target.updatedAt = now
            profiles.save(target)
        } else {
            existingProfile
        }

        return toResponse(account, profile)
    }

    @Transactional(readOnly = true)
    fun get(userId: UUID): IdentityProfileResponse {
        val account = findAccount(userId)
        return toResponse(account, profiles.findById(userId).orElse(null))
    }

    @Transactional
    fun update(
        userId: UUID,
        request: UpdateIdentityProfileRequest,
    ): IdentityProfileResponse {
        val account = findAccount(userId)
        val now = Instant.now()
        val profile = profiles.findById(userId).orElseGet {
            UserProfile(
                userId = userId,
                createdAt = now,
                updatedAt = now,
            )
        }

        profile.firstName = normalize(request.firstName)
        profile.lastName = normalize(request.lastName)
        profile.displayName = normalize(request.displayName)
        profile.avatarUrl = normalize(request.avatarUrl)
        profile.updatedAt = now
        profiles.save(profile)

        return toResponse(account, profile)
    }

    @Transactional(readOnly = true)
    fun merchantEligibility(userId: UUID): MerchantEligibilityResponse {
        val account = findAccount(userId)
        val reasons = linkedSetOf<String>()

        if (account.status != AccountStatus.ACTIVE) {
            reasons += MERCHANT_ACCOUNT_NOT_ACTIVE
        }
        if (!account.emailVerified) {
            reasons += MERCHANT_EMAIL_NOT_VERIFIED
        }
        if (account.profileStatus != ProfileStatus.COMPLETED) {
            reasons += MERCHANT_PROFILE_NOT_COMPLETED
        }

        return MerchantEligibilityResponse(
            userId = account.id,
            status = account.status.name,
            active = account.status == AccountStatus.ACTIVE,
            emailVerified = account.emailVerified,
            profileStatus = account.profileStatus.name,
            eligible = reasons.isEmpty(),
            reasons = reasons,
        )
    }

    @Transactional(readOnly = true)
    fun authContext(userId: UUID): IdentityAuthContext {
        val account = findAccount(userId)
        val authorization = roleService.getAuthorization(userId)

        return IdentityAuthContext(
            userId = account.id,
            status = account.status.name,
            active = account.status == AccountStatus.ACTIVE,
            emailVerified = account.emailVerified,
            roles = authorization.roles,
            permissions = authorization.permissions,
            authorizationVersion = account.authorizationVersion,
        )
    }


    @Transactional
    fun updateEmailVerification(
        userId: UUID,
        emailVerified: Boolean,
    ): IdentityAuthContext {
        val account = findAccount(userId)

        if (account.emailVerified != emailVerified) {
            account.emailVerified = emailVerified
            account.authorizationVersion += 1
            account.updatedAt = Instant.now()
            accounts.save(account)
        }

        return authContext(userId)
    }

    private fun findAccount(userId: UUID): UserAccount =
        accounts.findById(userId).orElseThrow { UserNotFoundException() }

    private fun toResponse(
        account: UserAccount,
        profile: UserProfile?,
    ) = IdentityProfileResponse(
        userId = account.id,
        email = account.email,
        status = account.status.name,
        emailVerified = account.emailVerified,
        firstName = profile?.firstName,
        lastName = profile?.lastName,
        displayName = profile?.displayName,
        avatarUrl = profile?.avatarUrl,
        authorizationVersion = account.authorizationVersion,
    )

    private fun normalize(value: String?): String? =
        value?.trim()?.takeIf { it.isNotEmpty() }

    companion object {
        private const val MERCHANT_ACCOUNT_NOT_ACTIVE = "ACCOUNT_NOT_ACTIVE"
        private const val MERCHANT_EMAIL_NOT_VERIFIED = "EMAIL_NOT_VERIFIED"
        private const val MERCHANT_PROFILE_NOT_COMPLETED = "PROFILE_NOT_COMPLETED"
    }
}
