package com.pavex.identity.controller

import io.swagger.v3.oas.annotations.security.SecurityRequirement
import io.swagger.v3.oas.annotations.tags.Tag
import com.pavex.identity.dto.user.CurrentUserResponse
import com.pavex.identity.dto.user.UpdateProfileRequest
import com.pavex.identity.service.UserService
import jakarta.validation.Valid
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.security.oauth2.jwt.Jwt
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import java.util.UUID

@RestController
@RequestMapping("/api/v1/auth")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Current User", description = "Current authenticated user profile")
class UserController(

    private val userService:
    UserService,
) {

    @GetMapping("/me")
    fun me(
        @AuthenticationPrincipal
        jwt: Jwt,
    ): CurrentUserResponse {

        return userService
            .getCurrentUser(
                getUserId(jwt)
            )
    }


    @PatchMapping("/me/profile")
    fun updateProfile(
        @AuthenticationPrincipal
        jwt: Jwt,

        @Valid
        @RequestBody
        request: UpdateProfileRequest,
    ): CurrentUserResponse {

        return userService
            .updateProfile(
                userId =
                    getUserId(jwt),

                request =
                    request,
            )
    }


    private fun getUserId(
        jwt: Jwt,
    ): UUID {

        return UUID.fromString(
            jwt.subject
        )
    }
}
